package com.employee.management.service;

import java.util.List;

import com.employee.management.exception.EmployeeMgmtServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.employee.management.model.Employee;
import com.employee.management.repository.EmployeeRepository;

// employee service class
@Service
public class EmployeeService {
  Logger log = LoggerFactory.getLogger(this.getClass());
  @Autowired private EmployeeRepository employeeRepository;

  // fetching all employees
  public List<Employee> getAllEmployees() {
    List<Employee> emps = (List<Employee>) employeeRepository.findAll();
    return emps;
  }

  // fetching employee by id
  public Employee getEmployee(int id) {

    try {
      return employeeRepository.findById(id).get();
    } catch (Exception e) {
      log.error("Exception occurred while processing getEmployee {} {}", id, e);
      throw new EmployeeMgmtServiceException(
          400, "operation failed", String.format("getEmployee operation failed employee:%d", id));
    }
  }

  // inserting employee
  public Employee addEmployee(Employee employee) {
    try {

      employee = employeeRepository.save(employee);
    } catch (Exception e) {
      log.error("Exception occurred while processing addEmployee {} {}", employee, e);
      throw new EmployeeMgmtServiceException(
          400,
          "operation failed",
          String.format("addEmployee operation failed employee:%d", employee));
    }
    return employee;
  }

  // updating employee by id
  public Employee updateEmployee(Employee emp, int id) {
    try {

      if (id == emp.getEmployeeID()) {
        emp = employeeRepository.save(emp);
      }
    } catch (Exception e) {
      log.error("Exception occurred while processing updateEmployee {} : {}", id, e);
      throw new EmployeeMgmtServiceException(
          400,
          "operation failed",
          String.format("updateEmployee operation failed employee:%d", id));
    }
    return emp;
  }

  // deleting all employees
  public void deleteAllEmployees() {
    try {
      employeeRepository.deleteAll();
    } catch (Exception e) {
      log.error("Exception occurred while processing deleteAllEmployees {}", e);
      throw new EmployeeMgmtServiceException(
          400, "operation failed", "deleteAllEmployees operation failed employee");
    }
  }

  // deleting employee by id
  public void deleteEmployeeByID(int id) {
    try {
      employeeRepository.deleteById(id);
    } catch (Exception e) {
      log.error("Exception occurred while processing deleteEmployeeByID {} : {}", id, e);
      throw new EmployeeMgmtServiceException(
          400,
          "operation failed",
          String.format("deleteEmployeeByID operation failed employee:%d", id));
    }
  }

  // patching/updating employee by id
  public Employee patchEmployee(Employee emp, int id) {
    try {
      if (id == emp.getEmployeeID()) {
        emp = employeeRepository.save(emp);
        log.info("updated employee:: {}", emp);
        System.out.println("updated emp = " + emp);
      }
    } catch (Exception e) {
      log.error("Exception occurred while processing patchEmployee {}, {}", id, e);
      throw new EmployeeMgmtServiceException(
          400, "operation failed", String.format("patchEmployee operation failed id:%d", id));
    }
    return emp;
  }
}
