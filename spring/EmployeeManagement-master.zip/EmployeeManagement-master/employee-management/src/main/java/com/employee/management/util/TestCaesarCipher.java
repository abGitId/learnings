package com.employee.management.util;

public class TestCaesarCipher {

  // Caesar Cipher Alogo implementation
  public static String getCaesarCipherText(String text, int key, int mode) {
    StringBuilder result = new StringBuilder();
    String alphabet = "abcdefghijklmnopqrstuvwyzABCDEFGHIJKLMNOPQRSTUVWYZ0123456789";
    for (int i = 0; i < text.length(); i++) {
      int c = text.charAt(i);
      int index = alphabet.indexOf(c);
      if (index == -1) {
        result.append(text.charAt(i));
      } else {
        int new_index = mode == 1 ? index + key : index - key;
        new_index = new_index < 0 ? alphabet.length() + new_index : new_index % alphabet.length();
        result.append(alphabet.substring(new_index, new_index + 1));
      }
    }
    return result.toString();
  }

  // decryption using Caesar Cipher
  public static String decrypt(String cipher) {
    int shift_constant = 2;
    // shift_mode = 1 shift towards right direction other than 1 is shift towards left direction
    int shift_mode_decrypt = -1;

    return getCaesarCipherText(cipher, shift_constant, shift_mode_decrypt);
  }

  // encryption using Caesar Cipher
  public static String encrypt(String message) {
    int shift_constant = 2;
    // shift_mode = 1 shift towards right direction other than 1 is shift towards left direction
    int shift_mode_encrypt = 1;

    return getCaesarCipherText(message, shift_constant, shift_mode_encrypt);
  }

  // Driver code
  public static void main(String[] args) {
    String message = "58d081d7-26f4-4347-a3ea-746b345590ff";
    String cipherText = encrypt(message);
    String decryptText = decrypt(cipherText);

    // output logs
    System.out.println("message= " + message);
    System.out.println("==================================================================");
    System.out.println("cipherText= " + cipherText);
    System.out.println("decryptedText= " + decryptText);
    System.out.println("==================================================================");
    System.out.println("verify decryptText status= " + decryptText.equals(message));
    System.out.println("==================================================================");
  }
}
