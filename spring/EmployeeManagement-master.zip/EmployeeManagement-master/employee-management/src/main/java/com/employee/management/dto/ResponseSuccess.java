package com.employee.management.dto;

import lombok.Data;

@Data
public class ResponseSuccess {
    private String status;
    private String message;
}
