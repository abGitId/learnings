package com.employee.management.util;

import java.util.stream.Stream;

public class TestDate {

  public static void main(String[] args) {
    //

    /* SimpleDateFormat sdf = new SimpleDateFormat("yyy-MM-dd");

    //Date date = new Date();
      sdf.setLenient(false);
    try {
      System.out.println(sdf.parse("20201-02-20"));

    } catch (ParseException e) {
      e.printStackTrace();
    }*/

    Stream.of("cat", "dog", "elephant", "fox", "rabbit", "duck")
        .forEach(
            pet -> {
              if ("fox".equalsIgnoreCase(pet)) {
                throw new RuntimeException();
              }
              System.out.println("pet = " + pet);
            });
  }
}
