package com.employee.management.dto;

import com.employee.management.model.Department;
import lombok.Data;

import javax.persistence.*;

@Data
public class EmpReq {

  private int employeeID;

  private String firstName;

  private String lastName;

  private String email;

  private Department department;

}
