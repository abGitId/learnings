package com.employee.management.dto;

import lombok.Data;

@Data
public class ErrorResponse {
  private String errorCode;
  private String errorTitle;
  private String errorMessage;
}
