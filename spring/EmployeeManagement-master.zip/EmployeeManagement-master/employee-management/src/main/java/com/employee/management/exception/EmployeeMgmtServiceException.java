package com.employee.management.exception;

public class EmployeeMgmtServiceException extends RuntimeException {

  int statusCode;
  String errorMessage;
  String errorCode;

  public EmployeeMgmtServiceException(int statusCode, String errorMessage, String errorCode) {
    this.statusCode = statusCode;
    this.errorMessage = errorMessage;
    this.errorCode = errorCode;
  }

  public int getStatusCode() {
    return statusCode;
  }

  public String getErrorMessage() {
    return errorMessage;
  }

  public String getErrorCode() {
    return errorCode;
  }
}
