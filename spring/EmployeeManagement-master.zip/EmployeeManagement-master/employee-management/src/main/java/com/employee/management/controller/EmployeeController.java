package com.employee.management.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.employee.management.model.Employee;
import com.employee.management.service.EmployeeService;

@RestController
public class EmployeeController {

  static final Logger logger = LogManager.getLogger(EmployeeController.class.getName());

  @Autowired private EmployeeService employeeService;

  // displaying list of all employees
  @GetMapping("/employees")
  public ResponseEntity<List<Employee>> getAllEmployee() {
    return ResponseEntity.ok(employeeService.getAllEmployees());
  }

  // displaying employee by id
  @GetMapping("/employees/{id}")
  public ResponseEntity<Employee> getEmployee(@PathVariable int id) {
    return ResponseEntity.ok(employeeService.getEmployee(id));
  }

  // inserting employee
  @PostMapping("/employees")
  public ResponseEntity<Employee> addEmployees(@RequestBody Employee employee) {
    return ResponseEntity.ok(employeeService.addEmployee(employee));
  }

  // updating employee by id
  @PutMapping("/employees/{id}")
  public ResponseEntity<Employee> updateEmployee(@RequestBody Employee e, @PathVariable int id) {
    return ResponseEntity.ok(employeeService.updateEmployee(e, id));
  }

  // deleting all employees
  @DeleteMapping("/employees")
  public ResponseEntity<?> deleteAllEmployees() {
    employeeService.deleteAllEmployees();
    return ResponseEntity.noContent().build();
  }

  // deleting employee by id
  @DeleteMapping("employees/{id}")
  public ResponseEntity<?> deleteEmployeeByID(@PathVariable int id) {
    employeeService.deleteEmployeeByID(id);
    return ResponseEntity.noContent().build();
  }

  // updating/ patching employee by id
  @PatchMapping("employees/{id}")
  public ResponseEntity<Employee> patchEmployeeByID(@RequestBody Employee e, @PathVariable int id) {
    e = employeeService.patchEmployee(e, id);
    return ResponseEntity.ok(e);
  }
}
