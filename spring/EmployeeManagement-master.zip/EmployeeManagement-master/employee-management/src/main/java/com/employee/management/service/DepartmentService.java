package com.employee.management.service;

import java.util.List;

import com.employee.management.exception.EmployeeMgmtServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import com.employee.management.model.Department;
import com.employee.management.repository.DepartmentRepository;

@Service
public class DepartmentService {

  Logger log = LoggerFactory.getLogger(this.getClass());
  @Autowired private DepartmentRepository departmentRepository;

  // fetching all department
  public List<Department> getAllDepartments() {
    List<Department> depts = (List<Department>) departmentRepository.findAll();
    return depts;
  }

  // fetching department by id
  public Department getDepartment(int id) {
    return departmentRepository.findById(id).get();
  }

  // inserting department
  public Department addDepartment(Department department) {
    department = saveOrUpdateDepartment(department);
    return department;
  }

  private Department saveOrUpdateDepartment(Department department) {
    try {
      department = departmentRepository.save(department);
    } catch (DataIntegrityViolationException violationException) {
      log.error("DataIntegrityViolationException occurred while processing {}", department);
      throw new EmployeeMgmtServiceException(
          400,
          "unique constraints validation failed",
          String.format(
              "unique constraints validation failed for dept:: %s", department.toString()));
    }
    return department;
  }

  // updating department by id
  public Department updateDepartment(Department department, int id) {
    if (id == department.getDepartment_ID()) {
      department = saveOrUpdateDepartment(department);
    } else {
      throw new EmployeeMgmtServiceException(
          400, "operation failed", "updateDepartment operation failed due to id mismatch");
    }
    return department;
  }

  // deleting all departments
  public void deleteAllDepartment() {
    try {

      departmentRepository.deleteAll();
    } catch (Exception e) {
      log.error("Exception occurred while processing deleteAllDepartment {}", e);
      throw new EmployeeMgmtServiceException(
          400, "operation failed", "deleteAllDepartment operation failed");
    }
  }

  // deleting department by id
  public void deleteDepartmentByID(int id) {

    try {

      departmentRepository.deleteById(id);
    } catch (Exception e) {
      log.error("Exception occurred while processing deleteAllDepartment {}", e);
      throw new EmployeeMgmtServiceException(
          400,
          "operation failed",
          String.format("deleteDepartmentByID operation failed id:%d", id));
    }
  }

  // patching/updating department by id
  public Department patchDepartment(Department department, int id) {
    if (id == department.getDepartment_ID()) {
      saveOrUpdateDepartment(department);
    }
    return department;
  }
}
