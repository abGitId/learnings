package com.employee.management.service;

import org.springframework.http.ResponseEntity;

public interface IAdminService {
    public ResponseEntity<?> getAdminData(int id);
}
