package com.employee.management.exception;

import com.employee.management.dto.ErrorResponse;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class EmployeeMgmtExceptionHandler extends ResponseEntityExceptionHandler {

  @ExceptionHandler(EmployeeMgmtServiceException.class)
  public ResponseEntity<?> handleChargeMasterServiceException(
      EmployeeMgmtServiceException ex, WebRequest request) {

    ErrorResponse errorResponse = new ErrorResponse();
    errorResponse.setErrorCode(ex.getErrorCode());
    errorResponse.setErrorMessage(ex.getErrorMessage());
    HttpHeaders headers = getDefaultConetentTypeHttpHeaders();
    return new ResponseEntity<>(errorResponse, headers, HttpStatus.BAD_REQUEST);
  }

  private HttpHeaders getDefaultConetentTypeHttpHeaders() {
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    return headers;
  }
}
