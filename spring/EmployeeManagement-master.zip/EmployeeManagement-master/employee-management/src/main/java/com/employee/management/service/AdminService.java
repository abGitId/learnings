package com.employee.management.service;

import com.employee.management.dto.ErrorResponse;
import com.employee.management.dto.ResponseSuccess;
import com.employee.management.exception.EmployeeMgmtServiceException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class AdminService implements IAdminService {
  public ResponseEntity<?> getAdminData(int id) {
    ResponseSuccess responseSuccess = new ResponseSuccess();
    ErrorResponse errorResponse = new ErrorResponse();
    if (id == 1) {
      responseSuccess.setMessage("welcome admin " + id);
      responseSuccess.setStatus("success");
      return ResponseEntity.ok(responseSuccess);
    } else {
      /*errorResponse.setErrorCode("E-004");
      errorResponse.setErrorMessage("User not found " + id);
      errorResponse.setErrorTitle("Resource not found");
      return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);*/
      throw new EmployeeMgmtServiceException(404, "User not found " + id, "E-004");
    }
  }
}
