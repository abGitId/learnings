package com.employee.management.controller;

import com.employee.management.dto.ErrorResponse;
import com.employee.management.dto.ResponseSuccess;
import com.employee.management.service.IAdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AdminController {

  @Autowired IAdminService adminService;

  @GetMapping("/admin")
  public ResponseEntity<ResponseSuccess> welcomeAdmin() {
    ResponseSuccess responseSuccess = new ResponseSuccess();
    responseSuccess.setMessage("welcome admin");
    responseSuccess.setStatus("success");
    return ResponseEntity.ok(responseSuccess);
  }

  @GetMapping("/admin/{id}")
  public ResponseEntity<?> getAdmin(@PathVariable int id) {
    return adminService.getAdminData(id);
  }
}
