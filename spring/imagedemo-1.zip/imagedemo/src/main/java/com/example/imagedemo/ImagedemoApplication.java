package com.example.imagedemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@SpringBootApplication
@RestController
public class ImagedemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImagedemoApplication.class, args);
	}


	@GetMapping("/")
	public ResponseEntity<?> greetings(){

		return ResponseEntity.ok("welcome to demo app");
	}

  @PostMapping("/upload")
  public ResponseEntity<byte []> uplaodImage(@RequestParam("imageFile") MultipartFile file)
      throws IOException {
    System.out.println("Original Image Byte Size - " + file.getBytes().length);
    System.out.println("Original Image File Name - " + file.getOriginalFilename());
	  HttpHeaders headers = new HttpHeaders();
	  byte[] media = file.getBytes();
	  headers.setCacheControl(CacheControl.noCache().getHeaderValue());
	  ResponseEntity<byte[]> responseEntity = new ResponseEntity<>(media, headers, HttpStatus.OK);
	  return responseEntity;
  }
}
